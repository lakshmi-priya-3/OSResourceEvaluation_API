using Microsoft.AspNetCore.Mvc;
using OSResourceEvaluationAPI.Repositories;

namespace OSResourceEvaluationAPI.Controllers
{
    [ApiController]
[Route("api/[controller]")]
public class OSResourceController : ControllerBase
{
    private readonly OSResourceRepository _repository;

    public OSResourceController(OSResourceRepository repository)
    {
        _repository = repository;
    }

    // 1. GET: /api/osresource/master/{osrpemId}
    [HttpGet("master/{osrpemId:int}")]
    public async Task<ActionResult<MasterDto>> GetMasterDetails(int osrpemId, CancellationToken ct)
    {
        var result = await _repository.GetMasterDetailsAsync(osrpemId, ct);
        if (result == null) return NotFound();
        return Ok(result);
    }

    // 2. GET: /api/osresource/activities/{osrpemId}
    [HttpGet("activities/{osrpemId:int}")]
    public async Task<ActionResult<List<ActivityDto>>> GetEmployeeActivities(int osrpemId, CancellationToken ct)
    {
        var result = await _repository.GetEmployeeActivitiesAsync(osrpemId, ct);
        return Ok(result);
    }

    // 3. GET: /api/osresource/parameters/{osrpemId}
    [HttpGet("parameters/{osrpemId:int}")]
    public async Task<ActionResult<List<EvaluationParamDto>>> GetEvaluationParameters(int osrpemId, CancellationToken ct)
    {
        var result = await _repository.GetEvaluationParametersAsync(osrpemId, ct);
        return Ok(result);
    }

    // 4. POST: /api/osresource/update-param-rating
    [HttpPost("update-param-rating")]
    public async Task<ActionResult> UpdateParamRatingByRM([FromBody] UpdateParamRatingRequest dto, CancellationToken ct)
    {
        var success = await _repository.UpdateParamRatingByRMAsync(dto.OSRPEEID, dto.RMRating, dto.RMWeightage, dto.RMRemarks, ct);
        return success ? Ok("Rating updated.") : BadRequest("Update failed.");
    }

    // 5. POST: /api/osresource/update-overall-rating
    [HttpPost("update-overall-rating")]
    public async Task<ActionResult> UpdateOverallRatingByRM([FromBody] UpdateOverallRatingRequest dto, CancellationToken ct)
    {
        var success = await _repository.UpdateOverallRatingByRMAsync(dto.OSRPEMId, dto.EvaluatedByRMMEmpId, dto.OverallRatingByRM, dto.EvalCommentsByRM, dto.TentativeDate, ct);
        return success ? Ok("Overall rating updated.") : BadRequest("Update failed.");
    }

    // 6. POST: /api/osresource/update-weightage
    [HttpPost("update-weightage")]
    public async Task<ActionResult> UpdateWeightageByEmployee([FromBody] UpdateWeightageRequest dto, CancellationToken ct)
    {
        var success = await _repository.UpdateWeightageByEmployeeAsync(dto.OSRPEMId, dto.ActMID, dto.EmpWeightage, dto.EmpRemarks, ct);
        return success ? Ok("Weightage updated.") : BadRequest("Update failed.");
    }
}
}