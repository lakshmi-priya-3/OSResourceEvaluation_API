namespace OSResourceEvaluationAPI.Models
{
    public class ActivityDto
    {
        public int ActMID { get; set; }
        public int ActDetailsMID { get; set; }
        public string Activity { get; set; } = string.Empty;
        public double ParamWeightage { get; set; }
        public double Weightage { get; set; }
        public string? EmployeeRemarks { get; set; }
    }
}
