namespace OSResourceEvaluationAPI.Models
{
public class UpdateParamRatingRequest
{
public int OSRPEEID { get; set; } // @OSRPEEID INT
public double RMRating { get; set; } // @RMRating FLOAT
public int RMWeightage { get; set; } // @RMWeightage INT
public string? RMRemarks { get; set; } // @RMRemarks NVARCHAR(1000)
}
}