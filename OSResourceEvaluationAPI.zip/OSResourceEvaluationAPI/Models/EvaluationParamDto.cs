namespace OSResourceEvaluationAPI.Models
{
    public class EvaluationParamDto
    {
        public int OSRPEMId { get; set; }
        public string Category { get; set; } = string.Empty;
        public string Parameter { get; set; } = string.Empty;
        public double Weightage { get; set; }
        public double? RMRating { get; set; }
        public int? RMWeightage { get; set; }
        public string? RMRemarks { get; set; }
        public string? ParameterDescription { get; set; }
    }
}
