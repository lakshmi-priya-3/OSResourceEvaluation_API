namespace OSResourceEvaluationAPI.Models
{
public class UpdateWeightageRequest
{
public int OSRPEMId { get; set; } // @OSRPEMId INT
public int ActMID { get; set; } // @ActMID INT
public double EmpWeightage { get; set; } // @EmpWeightage FLOAT
public string? EmpRemarks { get; set; } // @EmpRemarks NVARCHAR(MAX)
}
}