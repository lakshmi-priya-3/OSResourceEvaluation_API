namespace OSResourceEvaluationAPI.Models
{
    public class MasterDto
    {
        public int OSRPEMId { get; set; }
        public string EmployeeName { get; set; } = string.Empty;
        public bool IsTechOS { get; set; }
        public string? EvalCommentsByRM { get; set; }
    }
}
