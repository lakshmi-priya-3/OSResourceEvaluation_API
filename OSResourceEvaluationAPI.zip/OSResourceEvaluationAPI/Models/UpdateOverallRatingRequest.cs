namespace OSResourceEvaluationAPI.Models
{
public class UpdateOverallRatingRequest
{
public int OSRPEMId { get; set; } // @OSRPEMId INT
public int EvaluatedByRMMEmpId { get; set; } // @EvaluatedByRMMEmpId INT
public double OverallRatingByRM { get; set; } // @OverallRatingByRM FLOAT
public string? EvalCommentsByRM { get; set; } // @EvalCommentsByRM NVARCHAR(500)
public DateTime? TentativeDate { get; set; } // @TentativeDate DATETIME
}
}