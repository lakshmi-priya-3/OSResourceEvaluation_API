using System.Data;
using Microsoft.Data.SqlClient;
using OSResourceEvaluationAPI.Models;

namespace OSResourceEvaluationAPI.Repositories
{
    public class OSResourceRepository
    {
        private readonly IDbConnection _db;
            public OSResourceRepository(IDbConnection db) => _db = db;

    // Get master details for a given OSRPEMId
    public async Task<MasterDto?> GetMasterDetailsAsync(int osrpemId, CancellationToken ct = default)
    {
        using var cmd = _db.CreateCommand();
        cmd.CommandText = "OSResPE_GetMasterDetails";
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@OSRPEMId", SqlDbType.Int) { Value = osrpemId });

        if (_db.State != ConnectionState.Open) _db.Open();

        using var reader = await ((SqlCommand)cmd).ExecuteReaderAsync(ct);
        if (await reader.ReadAsync(ct))
        {
            return new MasterDto
            {
                OSRPEMId = reader.GetInt32(reader.GetOrdinal("OSRPEMId")),
                EmployeeName = reader.GetString(reader.GetOrdinal("EmployeeName")),
                IsTechOS = reader.GetBoolean(reader.GetOrdinal("IsTechOS")),
                EvalCommentsByRM = reader.IsDBNull(reader.GetOrdinal("EvalCommentsByRM")) ? null : reader.GetString(reader.GetOrdinal("EvalCommentsByRM"))
            };
        }
        return null;
    }

    // Get activities for a given OSRPEMId
    public async Task<List<ActivityDto>> GetEmployeeActivitiesAsync(int osrpemId, CancellationToken ct = default)
    {
        var list = new List<ActivityDto>();
        using var cmd = _db.CreateCommand();
        cmd.CommandText = "OSResPE_GetOSEmpActivities";
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@OSRPEMId", SqlDbType.Int) { Value = osrpemId });

        if (_db.State != ConnectionState.Open) _db.Open();

        using var reader = await ((SqlCommand)cmd).ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            list.Add(new ActivityDto
            {
                ActMID = reader.GetInt32(reader.GetOrdinal("ActMID")),
                ActDetailsMID = reader.GetInt32(reader.GetOrdinal("ActDetailsMID")),
                Activity = reader.GetString(reader.GetOrdinal("Activity")),
                ParamWeightage = Convert.ToDouble(reader["ParamWeightage"]),
                Weightage = Convert.ToDouble(reader["Weightage"]),
                EmployeeRemarks = reader["EmployeeRemarks"]?.ToString()
            });
        }

        return list;
    }

    // Get evaluation parameters for a given OSRPEMId
    public async Task<List<EvaluationParamDto>> GetEvaluationParametersAsync(int osrpemId, CancellationToken ct = default)
    {
        var list = new List<EvaluationParamDto>();
        using var cmd = _db.CreateCommand();
        cmd.CommandText = "OSResPE_GetEvaluationParameters_ByOSRPEMId";
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@OSRPEMId", SqlDbType.Int) { Value = osrpemId });

        if (_db.State != ConnectionState.Open) _db.Open();

        using var reader = await ((SqlCommand)cmd).ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            list.Add(new EvaluationParamDto
            {
                OSRPEMId = reader.GetInt32(reader.GetOrdinal("OSRPEMId")),
                Category = reader.GetString(reader.GetOrdinal("Category")),
                Parameter = reader.GetString(reader.GetOrdinal("Parameter")),
                Weightage = Convert.ToDouble(reader["Weightage"]),
                RMRating = reader.IsDBNull(reader.GetOrdinal("RMRating")) ? null : reader.GetDouble(reader.GetOrdinal("RMRating")),
                RMWeightage = reader.IsDBNull(reader.GetOrdinal("RMWeightage")) ? null : reader.GetInt32(reader.GetOrdinal("RMWeightage")),
                RMRemarks = reader["RMRemarks"]?.ToString(),
                ParameterDescription = reader["ParameterDescription"]?.ToString()
            });
        }

        return list;
    }

    // Update parameter rating by RM
    public async Task<bool> UpdateParamRatingByRMAsync(int osrpeeid, double rmRating, int rmWeightage, string? rmRemarks, CancellationToken ct = default)
    {
        using var cmd = _db.CreateCommand();
        cmd.CommandText = "OSResPE_UpdateParamRatingByRM";
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@OSRPEEID", SqlDbType.Int) { Value = osrpeeid });
        cmd.Parameters.Add(new SqlParameter("@RMRating", SqlDbType.Float) { Value = rmRating });
        cmd.Parameters.Add(new SqlParameter("@RMWeightage", SqlDbType.Int) { Value = rmWeightage });
        cmd.Parameters.Add(new SqlParameter("@RMRemarks", SqlDbType.NVarChar, 1000) { Value = (object?)rmRemarks ?? DBNull.Value });

        if (_db.State != ConnectionState.Open) _db.Open();

        var rows = await ((SqlCommand)cmd).ExecuteNonQueryAsync(ct);
        return rows > 0;
    }

    // Update overall rating by RM
    public async Task<bool> UpdateOverallRatingByRMAsync(int osrpemId, int evaluatorId, double overallRating, string? comments, DateTime? tentativeDate, CancellationToken ct = default)
    {
        using var cmd = _db.CreateCommand();
        cmd.CommandText = "OSResPE_UpdateOverallRatingByRM";
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@OSRPEMId", SqlDbType.Int) { Value = osrpemId });
        cmd.Parameters.Add(new SqlParameter("@EvaluatedByRMMEmpId", SqlDbType.Int) { Value = evaluatorId });
        cmd.Parameters.Add(new SqlParameter("@OverallRatingByRM", SqlDbType.Float) { Value = overallRating });
        cmd.Parameters.Add(new SqlParameter("@EvalCommentsByRM", SqlDbType.NVarChar, 500) { Value = (object?)comments ?? DBNull.Value });
        cmd.Parameters.Add(new SqlParameter("@TentativeDate", SqlDbType.DateTime) { Value = (object?)tentativeDate ?? DBNull.Value });

        if (_db.State != ConnectionState.Open) _db.Open();

        var rows = await ((SqlCommand)cmd).ExecuteNonQueryAsync(ct);
        return rows > 0;
    }

    // Update weightage by employee
    public async Task<bool> UpdateWeightageByEmployeeAsync(int osrpemId, int actMID, double empWeightage, string? empRemarks, CancellationToken ct = default)
    {
        using var cmd = _db.CreateCommand();
        cmd.CommandText = "OSResPE_UpdateWeightageByEmployee";
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@OSRPEMId", SqlDbType.Int) { Value = osrpemId });
        cmd.Parameters.Add(new SqlParameter("@ActMID", SqlDbType.Int) { Value = actMID });
        cmd.Parameters.Add(new SqlParameter("@EmpWeightage", SqlDbType.Float) { Value = empWeightage });
        cmd.Parameters.Add(new SqlParameter("@EmpRemarks", SqlDbType.NVarChar, -1) { Value = (object?)empRemarks ?? DBNull.Value });

        if (_db.State != ConnectionState.Open) _db.Open();

        var rows = await ((SqlCommand)cmd).ExecuteNonQueryAsync(ct);
        return rows > 0;
    }
}
}
