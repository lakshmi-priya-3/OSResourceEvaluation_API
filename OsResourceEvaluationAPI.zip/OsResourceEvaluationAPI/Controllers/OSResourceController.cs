using Microsoft.AspNetCore.Mvc;
using OsResourceEvaluationAPI.Repositories;

namespace OsResourceEvaluationAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OsResourceController : ControllerBase
    {
        private readonly OsResourceRepository _repo;
        public OsResourceController(OsResourceRepository repo) => _repo = repo;
        

        [HttpGet("master/{id}")]
        public async Task<IActionResult> GetMasterDetails(int id)
            => Ok(await _repo.GetMasterDetailsAsync(id));

        [HttpGet("activities/{id}")]
        public async Task<IActionResult> GetActivities(int id)
            => Ok(await _repo.GetEmployeeActivitiesAsync(id));

        [HttpGet("parameters/{id}")]
        public async Task<IActionResult> GetParameters(int id)
            => Ok(await _repo.GetEvaluationParametersAsync(id));

        [HttpPost("update-param-rating")]
        public async Task<IActionResult> UpdateParamRating([FromQuery] int masterId, [FromQuery] int paramId, [FromQuery] int rating)
            => Ok(await _repo.UpdateParamRatingByRMAsync(masterId, paramId, rating));

        [HttpPost("update-overall-rating")]
        public async Task<IActionResult> UpdateOverallRating([FromQuery] int masterId, [FromQuery] int overallRating)
            => Ok(await _repo.UpdateOverallRatingByRMAsync(masterId, overallRating));

        [HttpPost("update-weightage")]
        public async Task<IActionResult> UpdateWeightage([FromQuery] int masterId, [FromQuery] int paramId, [FromQuery] decimal weightage)
            => Ok(await _repo.UpdateWeightageByEmployeeAsync(masterId, paramId, weightage));
    }
}
