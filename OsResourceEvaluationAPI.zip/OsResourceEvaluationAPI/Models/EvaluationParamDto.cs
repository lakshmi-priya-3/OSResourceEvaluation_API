namespace OsResourceEvaluationAPI.Models
{
    public class EvaluationParamDto
    {
        public int ParamId { get; set; }
        public string ParamName { get; set; } = string.Empty;
        public int MaxScore { get; set; }
    }
}
