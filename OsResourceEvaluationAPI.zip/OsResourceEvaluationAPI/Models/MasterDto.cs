namespace OsResourceEvaluationAPI.Models
{
    public class MasterDto
    {
        public int MasterId { get; set; }
        public string Name { get; set; } = string.Empty;
        public DateTime CreatedOn { get; set; }
        public bool IsActive { get; set; }
    }
}
