namespace OsResourceEvaluationAPI.Models
{
    public class ActivityDto
    {
        public int OSRPEMId { get; set; }
        public string Name { get; set; } = string.Empty;
        public DateTime JoinDate { get; set; }
    }
}
