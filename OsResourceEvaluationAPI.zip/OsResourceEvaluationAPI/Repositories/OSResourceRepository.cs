using System.Data;
using Microsoft.Data.SqlClient;
using OsResourceEvaluationAPI.Models;

namespace OsResourceEvaluationAPI.Repositories
{
    public class OsResourceRepository
    {
        private readonly IDbConnection _db;
        public OsResourceRepository(IDbConnection db) => _db = db;

        // 1. Get Master Details
        public async Task<MasterDto?> GetMasterDetailsAsync(int masterId, CancellationToken ct = default)
        {
            using var cmd = _db.CreateCommand();
            cmd.CommandText = "OSResPE_GetMasterDetails";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@OSRPEMId", SqlDbType.Int) { Value = masterId });

            if (_db.State != ConnectionState.Open) _db.Open();
            using var reader = await ((SqlCommand)cmd).ExecuteReaderAsync(ct);
            if (await reader.ReadAsync(ct))
            {
                return new MasterDto
                {
                    MasterId = reader.GetInt32(reader.GetOrdinal("MasterId")),
                    Name = reader.GetString(reader.GetOrdinal("Name")),
                    CreatedOn = reader.GetDateTime(reader.GetOrdinal("CreatedOn")),
                    IsActive = reader.GetBoolean(reader.GetOrdinal("IsActive"))
                };
            }
            return null;
        }

        // 2. Get Employee Activities
        public async Task<List<ActivityDto>> GetEmployeeActivitiesAsync(int masterId, CancellationToken ct = default)
        {
            var list = new List<ActivityDto>();
            using var cmd = _db.CreateCommand();
            cmd.CommandText = "OSResPE_GetOSEmpActivities";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@OSRPEMId", SqlDbType.Int) { Value = masterId });

            if (_db.State != ConnectionState.Open) _db.Open();
            using var reader = await ((SqlCommand)cmd).ExecuteReaderAsync(ct);
            while (await reader.ReadAsync(ct))
            {
                list.Add(new ActivityDto
                {
                    OSRPEMId = reader.GetInt32(reader.GetOrdinal("OSRPEMId")),
                    Name = reader.GetString(reader.GetOrdinal("Name")),
                    JoinDate = reader.GetDateTime(reader.GetOrdinal("JoinDate"))
                });
            }
            return list;
        }

        // 3. Get Evaluation Parameters
        public async Task<List<EvaluationParamDto>> GetEvaluationParametersAsync(int masterId, CancellationToken ct = default)
        {
            var list = new List<EvaluationParamDto>();
            using var cmd = _db.CreateCommand();
            cmd.CommandText = "OSResPE_GetEvaluationParameters_ByOSRPEMID";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@OSRPEMId", SqlDbType.Int) { Value = masterId });

            if (_db.State != ConnectionState.Open) _db.Open();
            using var reader = await ((SqlCommand)cmd).ExecuteReaderAsync(ct);
            while (await reader.ReadAsync(ct))
            {
                list.Add(new EvaluationParamDto
                {
                    ParamId = reader.GetInt32(reader.GetOrdinal("ParamId")),
                    ParamName = reader.GetString(reader.GetOrdinal("ParamName")),
                    MaxScore = reader.GetInt32(reader.GetOrdinal("MaxScore"))
                });
            }
            return list;
        }

        // 4. Update Parameter Rating by RM
        public async Task<bool> UpdateParamRatingByRMAsync(int masterId, int paramId, int rating, CancellationToken ct = default)
        {
            using var cmd = _db.CreateCommand();
            cmd.CommandText = "OSResPE_UpdateParamRatingByRM";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@OSRPEMId", SqlDbType.Int) { Value = masterId });
            cmd.Parameters.Add(new SqlParameter("@ParamId", SqlDbType.Int) { Value = paramId });
            cmd.Parameters.Add(new SqlParameter("@Rating", SqlDbType.Int) { Value = rating });

            if (_db.State != ConnectionState.Open) _db.Open();
            var rows = await ((SqlCommand)cmd).ExecuteNonQueryAsync(ct);
            return rows > 0;
        }

        // 5. Update Overall Rating by RM
        public async Task<bool> UpdateOverallRatingByRMAsync(int masterId, int overallRating, CancellationToken ct = default)
        {
            using var cmd = _db.CreateCommand();
            cmd.CommandText = "OSResPE_UpdateOverallRatingByRM";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@OSRPEMId", SqlDbType.Int) { Value = masterId });
            cmd.Parameters.Add(new SqlParameter("@OverallRating", SqlDbType.Int) { Value = overallRating });

            if (_db.State != ConnectionState.Open) _db.Open();
            var rows = await ((SqlCommand)cmd).ExecuteNonQueryAsync(ct);
            return rows > 0;
        }

        // 6. Update Weightage By Employee
        public async Task<bool> UpdateWeightageByEmployeeAsync(int masterId, int paramId, decimal weightage, CancellationToken ct = default)
        {
            using var cmd = _db.CreateCommand();
            cmd.CommandText = "OSResPE_UpdateWeigtageByEmployee";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@OSRPEMId", SqlDbType.Int) { Value = masterId });
            cmd.Parameters.Add(new SqlParameter("@ParamId", SqlDbType.Int) { Value = paramId });
            cmd.Parameters.Add(new SqlParameter("@Weightage", SqlDbType.Decimal) { Precision = 5, Scale = 2, Value = weightage });

            if (_db.State != ConnectionState.Open) _db.Open();
            var rows = await ((SqlCommand)cmd).ExecuteNonQueryAsync(ct);
            return rows > 0;
        }
    }
}
